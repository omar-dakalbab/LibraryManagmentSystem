﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace LibraryManagmentSystem.Connection
{
    public static class ConnectionForBooksMsg
    {
        public static string stringConnection = "Data Source = OMAR-DAKELBAB; Initial Catalog = LibraryDatabase; Integrated Security = True";
        public static bool blCheck = true;

        public static DataTable executeSQL(string sql, string MessageError)
        {
            SqlCommand cmd = new SqlCommand();
            SqlConnection connection = new SqlConnection();
            SqlDataAdapter adapter = default(SqlDataAdapter);
            DataTable dt = new DataTable();

            try
            {
                connection.ConnectionString = stringConnection;
                connection.Open();

                adapter = new SqlDataAdapter(sql, connection);

                adapter.Fill(dt);              
                blCheck = true;
                connection.Close();
                connection = null;
                return dt;
            }
            catch (Exception)
            {
                MessageBox.Show(MessageError);
                blCheck = false;
                dt = null;
            }
            return dt;

        }
    }
}
