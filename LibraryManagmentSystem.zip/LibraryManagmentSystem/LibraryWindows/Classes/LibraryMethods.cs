﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManagmentSystem.LibraryWindows
{
    public static class LibraryMethods
    {
        public static void addbook(string BookName, string BookCategory, string AuthorName, string Quantity, string BookYear, string PageNumber)
        {
           
               if(BookName != "" && BookCategory != "" && AuthorName != "" && Quantity != "" && BookYear != "" && PageNumber != "")
                {
                    Connection.LibraryConnection.executeSQL("insert into BookTbl(Book_PageNumber, Book_Name, Book_Quantity, Book_Author_Name, Book_Category, Book_PublishedYear, Book_ID)" +
                        "VALUES('" + PageNumber + "','" + BookName + "', '" + Quantity + "', '" + AuthorName + "','" + BookCategory + "', '" + BookYear + "', '" + Login_SignupWindows.AdditionalClasses.Static.BookIDRandomizer() + "')" 
                        , "Book Added");
                }
            
            
        }
        public static void updatebook(string BookName, string BookCategory, string AuthorName, string Quantity, string BookYear, string PageNumber, string bookIDTxt)
        {
            Connection.LibraryConnection.executeSQL("UPDATE BookTbl SET Book_Name='"+BookName+"',Book_Category='"+BookCategory+"',Book_Author_Name='"+ AuthorName +"', Book_Quantity='"+Quantity+"', Book_PublishedYear='"+ BookYear +"', Book_PageNumber='"+PageNumber+"' WHERE Book_ID='"+ bookIDTxt +"' "              
                ,"Book Updated");
        }
        public static void deletebook(string BookName, string BookCategory, string AuthorName, string Quantity, string BookYear, string PageNumber, string bookIDTxt)
        {
            if(BookName != "" && BookCategory != "" && AuthorName != "" && Quantity != "" && BookYear != ""&& PageNumber != "")
            {
                Connection.LibraryConnection.executeSQL("DELETE BookTbl Where Book_ID='" + bookIDTxt + "'","Book Deleted");
            }
        }




    }
}
