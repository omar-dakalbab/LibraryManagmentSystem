﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LibraryManagmentSystem.LibraryWindows
{
    /// <summary>
    /// Interaction logic for AddedBooksWindow.xaml
    /// </summary>
    public partial class AddedBooksWindow : Window
    {
        public AddedBooksWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            using (SqlConnection con = new SqlConnection(Connection.LibraryConnection.stringConnection))
            {
                con.Open();
                using (SqlDataAdapter a = new SqlDataAdapter(
                    "SELECT * FROM AddedBooksTbl", con))
                {
                    DataTable t = new DataTable();
                    a.Fill(t);
                    addedBooksDataGrid.ItemsSource = t.DefaultView;



                    // https://stackoverflow.com/questions/52578966/wpf-binding-BooksDatagrid-with-sql-server-database-table/52579280
                }
            }
        }

        private void GoBackBtn_Click(object sender, RoutedEventArgs e)
        {
            AdminPanel adminPanel = new AdminPanel();
            adminPanel.Show();
            this.Close();
        }
    }
}
