﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LibraryManagmentSystem.LibraryWindows
{
    /// <summary>
    /// Interaction logic for TeacherDatabase.xaml
    /// </summary>
    public partial class TeacherDatabase : Window
    {
        public TeacherDatabase()
        {
            InitializeComponent();
        }

        private void GoBackBtn_Click(object sender, RoutedEventArgs e)
        {
            AdminPanel adminPanel = new AdminPanel();
            adminPanel.Show();
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            
            using (SqlConnection con = new SqlConnection(Connection.LibraryConnection.stringConnection))
            {
                con.Open();
                using (SqlDataAdapter a = new SqlDataAdapter(
                    "SELECT User_ID,Username,Email,First_Name,Last_Name,DateOfBirth,AddedBook,MaxBook FROM TeachersTbl", con))
                {
                    DataTable t = new DataTable();
                    a.Fill(t);
                    TeacherDatagrid.ItemsSource = t.DefaultView;



                    // https://stackoverflow.com/questions/52578966/wpf-binding-BooksDatagrid-with-sql-server-database-table/52579280
                }
            }
        }

        private void updateMaxBookBtn_Click(object sender, RoutedEventArgs e)
        {
            if (lblusername.Text == "")
            {
                System.Windows.MessageBox.Show("Please select a user");
                return;
            }
            else
            {
                Connection.LibraryConnection.executeSQL("UPDATE TeachersTbl SET MaxBook='" + updateAddedBookTxt.Text + "' WHERE User_ID='" + lblusername.Text + "'", "Data Updated");
                using (SqlConnection con = new SqlConnection(Connection.LibraryConnection.stringConnection))
                {
                    con.Open();
                    using (SqlDataAdapter a = new SqlDataAdapter(
                        "SELECT User_ID,Username,Email,First_Name,Last_Name,DateOfBirth,AddedBook,MaxBook FROM TeachersTbl", con))
                    {
                        DataTable t = new DataTable();
                        a.Fill(t);
                        TeacherDatagrid.ItemsSource = t.DefaultView;



                        // https://stackoverflow.com/questions/52578966/wpf-binding-BooksDatagrid-with-sql-server-database-table/52579280
                    }
                }
            }
        }

        private void TeachersDBSearchTxt_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (TeachersDBCombo.SelectedIndex == 0)
            {
                BindingSource bs = new BindingSource();
                bs.DataSource = TeacherDatagrid.ItemsSource;
                bs.Filter = "Convert(User_ID, 'System.String') LIKE '%" + TeachersDBSearchTxt.Text + "%'";
                TeacherDatagrid.ItemsSource = bs;
            }
            if (TeachersDBCombo.SelectedIndex == 1)
            {
                BindingSource bs = new BindingSource();
                bs.DataSource = TeacherDatagrid.ItemsSource;
                bs.Filter = "Username LIKE '%" + TeachersDBSearchTxt.Text + "%'";
                TeacherDatagrid.ItemsSource = bs;
            }
            if (TeachersDBCombo.SelectedIndex == 2)
            {
                BindingSource bs = new BindingSource();
                bs.DataSource = TeacherDatagrid.ItemsSource;
                bs.Filter = "Email LIKE '%" + TeachersDBSearchTxt.Text + "%'";
                TeacherDatagrid.ItemsSource = bs;
            }
            if (TeachersDBCombo.SelectedIndex == 3)
            {
                BindingSource bs = new BindingSource();
                bs.DataSource = TeacherDatagrid.ItemsSource;
                bs.Filter = "First_Name LIKE '%" + TeachersDBSearchTxt.Text + "%'";
                TeacherDatagrid.ItemsSource = bs;
            }
            if (TeachersDBCombo.SelectedIndex == 4)
            {
                BindingSource bs = new BindingSource();
                bs.DataSource = TeacherDatagrid.ItemsSource;
                bs.Filter = "Last_Name LIKE '%" + TeachersDBSearchTxt.Text + "%'";
                TeacherDatagrid.ItemsSource = bs;
            }
            if (TeachersDBCombo.SelectedIndex == 5)
            {
                BindingSource bs = new BindingSource();
                bs.DataSource = TeacherDatagrid.ItemsSource;
                bs.Filter = "Convert(DateOfBirth, 'System.String') LIKE '%" + TeachersDBSearchTxt.Text + "%'";
                TeacherDatagrid.ItemsSource = bs;
            }

        }
    }
}
