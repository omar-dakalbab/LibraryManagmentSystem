﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LibraryManagmentSystem.LibraryWindows.AdminWindows
{
    /// <summary>
    /// Interaction logic for MessagesWindow.xaml
    /// </summary>
    public partial class MessagesWindow : Window
    {
        public MessagesWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            comboBox.SelectedItem = "Student Database";
        }

        private void GoBackBtn_Click(object sender, RoutedEventArgs e)
        {
            AdminPanel adminPanel = new AdminPanel();
            adminPanel.Show();
            this.Close();
        }

        private void refreshBtn_Click(object sender, RoutedEventArgs e)
        {
            if (comboBox.SelectedIndex == 0)
            {
                using (SqlConnection con = new SqlConnection(Connection.LibraryConnection.stringConnection))
                {
                    con.Open();
                    using (SqlDataAdapter a = new SqlDataAdapter(
                        "SELECT * FROM StudentsTbl", con))
                    {
                        DataTable t = new DataTable();
                        a.Fill(t);
                        databaseDatagrid.ItemsSource = t.DefaultView;



                        // https://stackoverflow.com/questions/52578966/wpf-binding-BooksDatagrid-with-sql-server-database-table/52579280
                    }
                }
            }
            if (comboBox.SelectedIndex == 1)
            {
                using (SqlConnection con = new SqlConnection(Connection.LibraryConnection.stringConnection))
                {
                    con.Open();
                    using (SqlDataAdapter a = new SqlDataAdapter(
                        "SELECT * FROM TeachersTbl", con))
                    {
                        DataTable t = new DataTable();
                        a.Fill(t);
                        databaseDatagrid.ItemsSource = t.DefaultView;



                        // https://stackoverflow.com/questions/52578966/wpf-binding-BooksDatagrid-with-sql-server-database-table/52579280
                    }
                }
            }
            
        }
        

        private void sendMsg_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(ToTxt.Text))
            {
                MessageBox.Show("Please enter a email");
                return;
            }
            if (string.IsNullOrEmpty(MessageBodyTxt.Text))
            {
                MessageBox.Show("Please enter your message");
                return;
            }
            else
            {
              Emails.EmailSentMessage.email(ToTxt.Text, MessageBodyTxt.Text, "New message from Library Managment System (LMS)", "Email Sent successfully");
            }        
        }
    }
}
