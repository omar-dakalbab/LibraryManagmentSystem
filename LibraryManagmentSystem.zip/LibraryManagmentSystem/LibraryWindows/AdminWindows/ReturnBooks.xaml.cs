﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LibraryManagmentSystem.LibraryWindows
{
    /// <summary>
    /// Interaction logic for ReturnBooks.xaml
    /// </summary>
    public partial class ReturnBooks : Window
    {
        public ReturnBooks()
        {
            InitializeComponent();
        }

        private void AcceptBtn_Click(object sender, RoutedEventArgs e)
        {
            Connection.LibraryConnection.executeSQL("UPDATE BookTbl SET Book_Quantity = Book_Quantity + 1 WHERE Book_ID ='" + BookIDTxt.Text + "' " +
                "DELETE ReturnedBooksTbl WHERE Book_ID='" + BookIDTxt.Text + "' AND ReturnedBy='" + returnedByTxt.Text + "'", "Book Accepted");
            if (Connection.LibraryConnection.blCheck == false)
            {
                return;
            }
            using (SqlConnection con = new SqlConnection(Connection.LibraryConnection.stringConnection))
            {
                con.Open();
                using (SqlDataAdapter a = new SqlDataAdapter(
                    "SELECT * FROM ReturnedBooksTbl", con))
                {
                    DataTable t = new DataTable();
                    a.Fill(t);
                    returnedBooksDatagrid.ItemsSource = t.DefaultView;



                    // https://stackoverflow.com/questions/52578966/wpf-binding-datagrid-with-sql-server-database-table/52579280
                }
            }
        }

        private void RejectBtn_Click(object sender, RoutedEventArgs e)
        {

        }

        private void SendBtn_Click(object sender, RoutedEventArgs e)
        {

        }

        private void GoBackBtn_Click(object sender, RoutedEventArgs e)
        {
            LibraryWindows.AdminPanel adminPanel = new AdminPanel();
            adminPanel.Show();
            this.Close();
        }

       

        private void LogoutBtn_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            using (SqlConnection con = new SqlConnection(Connection.LibraryConnection.stringConnection))
            {
                con.Open();
                using (SqlDataAdapter a = new SqlDataAdapter(
                    "SELECT * FROM ReturnedBooksTbl", con))
                {
                    DataTable t = new DataTable();
                    a.Fill(t);
                    returnedBooksDatagrid.ItemsSource = t.DefaultView;



                    // https://stackoverflow.com/questions/52578966/wpf-binding-datagrid-with-sql-server-database-table/52579280
                }
            }
        }
    }
}
