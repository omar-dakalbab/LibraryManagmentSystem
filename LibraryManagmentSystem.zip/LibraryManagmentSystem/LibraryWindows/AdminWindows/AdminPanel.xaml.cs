﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LibraryManagmentSystem.LibraryWindows
{
    /// <summary>
    /// Interaction logic for AdminPanel.xaml
    /// </summary>
    public partial class AdminPanel : Window
    {
        public AdminPanel()
        {
            InitializeComponent();
        }

        private void AddBookBtn_Click(object sender, RoutedEventArgs e)
        {
            LibraryMethods.addbook(BookNameTxt.Text, CategoryTxt.Text, AuthorNameTxt.Text, QunatityTxt.Text, PublishedYearTxt.Text, PageNumberTxt.Text);
            using (SqlConnection con = new SqlConnection(Connection.LibraryConnection.stringConnection))
            {
                con.Open();
                using (SqlDataAdapter a = new SqlDataAdapter(
                    "SELECT Book_ID,Book_Name,Book_Author_Name,Book_PageNumber,Book_Quantity,Book_PublishedYear,Book_Category FROM BookTbl", con))
                {
                    DataTable t = new DataTable();
                    a.Fill(t);
                    BooksDatagrid.ItemsSource = t.DefaultView;



                    // https://stackoverflow.com/questions/52578966/wpf-binding-datagrid-with-sql-server-database-table/52579280
                }
            }
        }

        private void UpdateBookBtn_Click(object sender, RoutedEventArgs e)
        {
            LibraryMethods.updatebook(BookNameTxt.Text, CategoryTxt.Text, AuthorNameTxt.Text, QunatityTxt.Text, PublishedYearTxt.Text, PageNumberTxt.Text, bookIdTxt.Text);
            using (SqlConnection con = new SqlConnection(Connection.LibraryConnection.stringConnection))
            {
                con.Open();
                using (SqlDataAdapter a = new SqlDataAdapter(
                    "SELECT Book_ID,Book_Name,Book_Author_Name,Book_PageNumber,Book_Quantity,Book_PublishedYear,Book_Category FROM BookTbl", con))
                {
                    DataTable t = new DataTable();
                    a.Fill(t);
                    BooksDatagrid.ItemsSource = t.DefaultView;



                    // https://stackoverflow.com/questions/52578966/wpf-binding-datagrid-with-sql-server-database-table/52579280
                }
            }
        }

        private void DeleteBookBtn_Click(object sender, RoutedEventArgs e)
        {
            LibraryMethods.deletebook(BookNameTxt.Text, CategoryTxt.Text, AuthorNameTxt.Text, QunatityTxt.Text, PublishedYearTxt.Text, PageNumberTxt.Text, bookIdTxt.Text);
            using (SqlConnection con = new SqlConnection(Connection.LibraryConnection.stringConnection))
            {
                con.Open();
                using (SqlDataAdapter a = new SqlDataAdapter(
                    "SELECT Book_ID,Book_Name,Book_Author_Name,Book_PageNumber,Book_Quantity,Book_PublishedYear,Book_Category FROM BookTbl", con))
                {
                    DataTable t = new DataTable();
                    a.Fill(t);
                    BooksDatagrid.ItemsSource = t.DefaultView;



                    // https://stackoverflow.com/questions/52578966/wpf-binding-datagrid-with-sql-server-database-table/52579280
                }
            }
        }

        private void LogoutBtn_Click(object sender, RoutedEventArgs e)
        {
            Login_SignupWindows.LoginWindow loginWindow = new Login_SignupWindows.LoginWindow();
            loginWindow.Show();
            this.Close();
        }

        private void ReturnedBooksBtn_Click(object sender, RoutedEventArgs e)
        {
            LibraryWindows.ReturnBooks returnedBooks = new ReturnBooks();
            returnedBooks.Show();
            this.Close();
        }

        private void TeachersRequestsBtn_Click(object sender, RoutedEventArgs e)
        {
            LibraryWindows.TeacherRequests teacherReq = new TeacherRequests();
            teacherReq.Show();
            this.Close();
        }

        private void UsersDatabaseBtn_Click(object sender, RoutedEventArgs e)
        {
            UsersDatabase userDatabase = new UsersDatabase();
            userDatabase.Show();
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            lblUserLoggedInName.Content = "Hey! "+ Login_SignupWindows.LoginWindow.recBy;
            using (SqlConnection con = new SqlConnection(Connection.LibraryConnection.stringConnection))
            {
                con.Open();
                using (SqlDataAdapter a = new SqlDataAdapter(
                    "SELECT Book_ID,Book_Name,Book_Author_Name,Book_PageNumber,Book_Quantity,Book_PublishedYear,Book_Category FROM BookTbl", con))
                {
                    DataTable t = new DataTable();
                    a.Fill(t);
                    BooksDatagrid.ItemsSource = t.DefaultView;



                    // https://stackoverflow.com/questions/52578966/wpf-binding-datagrid-with-sql-server-database-table/52579280
                }
            }
        }

        private void BooksSearchBarTxt_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (BooksComboBox.SelectedIndex == 0)
            {
                BindingSource bs = new BindingSource();
                bs.DataSource = BooksDatagrid.ItemsSource;
                bs.Filter = "Book_Name LIKE '%" + BooksSearchBarTxt.Text + "%'";
                BooksDatagrid.ItemsSource = bs;
            }
            if (BooksComboBox.SelectedIndex == 1)
            {
                BindingSource bs = new BindingSource();
                bs.DataSource = BooksDatagrid.ItemsSource;
                bs.Filter = "Convert(Book_PageNumber, 'System.String') LIKE '%" + BooksSearchBarTxt.Text + "%'";
                BooksDatagrid.ItemsSource = bs;
            }
            if (BooksComboBox.SelectedIndex == 2)
            {
                BindingSource bs = new BindingSource();
                bs.DataSource = BooksDatagrid.ItemsSource;
                bs.Filter = "Book_Author_Name LIKE '%" + BooksSearchBarTxt.Text + "%'";
                BooksDatagrid.ItemsSource = bs;
            }
            if (BooksComboBox.SelectedIndex == 3)
            {
                BindingSource bs = new BindingSource();
                bs.DataSource = BooksDatagrid.ItemsSource;
                bs.Filter = "Book_Category LIKE '%" + BooksSearchBarTxt.Text + "%'";
                BooksDatagrid.ItemsSource = bs;
            }
            if (BooksComboBox.SelectedIndex == 4)
            {
                BindingSource bs = new BindingSource();
                bs.DataSource = BooksDatagrid.ItemsSource;
                bs.Filter = "Convert(Book_PublishedYear, 'System.String') LIKE '%" + BooksSearchBarTxt.Text + "%'";
                BooksDatagrid.ItemsSource = bs;
            }
            if (BooksComboBox.SelectedIndex == 5)
            {
                BindingSource bs = new BindingSource();
                bs.DataSource = BooksDatagrid.ItemsSource;
                bs.Filter = "Convert(Book_Quantity, 'System.String') LIKE '%" + BooksSearchBarTxt.Text + "%'";
                BooksDatagrid.ItemsSource = bs;
            }
           
        }

        private void bookstake_Click(object sender, RoutedEventArgs e)
        {
            AddedBooksWindow addedBooksWin = new AddedBooksWindow();
            addedBooksWin.Show();
            this.Close();
        }

        private void TeacherDB_Click(object sender, RoutedEventArgs e)
        {
            TeacherDatabase teacherDB = new TeacherDatabase();
            teacherDB.Show();
            this.Close(); 
        }

        private void SentMessagebtn_Click(object sender, RoutedEventArgs e)
        {
            AdminWindows.MessagesWindow messageWin = new AdminWindows.MessagesWindow();
            messageWin.Show();
            this.Close();
        }
    }
}
