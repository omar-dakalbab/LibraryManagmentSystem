﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LibraryManagmentSystem.LibraryWindows
{
    /// <summary>
    /// Interaction logic for TeacherRequests.xaml
    /// </summary>
    public partial class TeacherRequests : Window
    {
        public TeacherRequests()
        {
            InitializeComponent();
        }
        private void AcceptBtn_Click(object sender, RoutedEventArgs e)
        {
            int addedBook = 0;
            int maxBook = 200;
            string teacherRole = "Teacher";
            Connection.LibraryConnection.executeSQL("INSERT INTO TeachersTbl (User_ID, Username, First_Name, Last_Name, Role, Password, Email, DateOfBirth, AddedBook, MaxBook)" +
                "SELECT User_ID, Username, First_Name, Last_Name, '" + teacherRole.ToUpper() + "', Password, Email, DateOfBirth,'"+addedBook+ "','" + maxBook + "' FROM StudentsTbl where Username ='" + lblUSername.Text + "' ", "The user has been added");
            Connection.ServerWithoutMsgBox.executeSQL("Delete StudentsTbl WHERE Username='"+lblUSername.Text+"'");
            using (SqlConnection con = new SqlConnection(Connection.LibraryConnection.stringConnection))
            {
                con.Open();
                using (SqlDataAdapter a = new SqlDataAdapter(
                    "SELECT * FROM StudentsTbl WHERE Role = '"+ "Pending Request" +"'", con))
                {
                    DataTable t = new DataTable();
                    a.Fill(t);
                    TeachersReqDatagrid.ItemsSource = t.DefaultView;
                    // https://stackoverflow.com/questions/52578966/wpf-binding-datagrid-with-sql-server-database-table/52579280
                }
            }
        }
        private void RejectBtn_Click(object sender, RoutedEventArgs e)
        {
            Connection.ServerWithoutMsgBox.executeSQL("UPDATE StudentsTbl SET Role='"+ "Student_NA" +"' WHERE Username='"+ lblUSername.Text +"'");
            Emails.EmailSentMessage.email(txtEmail.Text ,"Hi, \nYou've been rejected from being a teacher in our LMS(Library Managment System).\nIf you have any questions you can contact us example@gmail.com", "Teacher Request (Library Managment System)", "Your Email has been sent");
            using (SqlConnection con = new SqlConnection(Connection.LibraryConnection.stringConnection))
            {
                con.Open();
                using (SqlDataAdapter a = new SqlDataAdapter(
                    "SELECT * FROM StudentsTbl WHERE Role='" + "Pending Request" + "'", con))
                {
                    DataTable t = new DataTable();
                    a.Fill(t);
                    TeachersReqDatagrid.ItemsSource = t.DefaultView;
                    // https://stackoverflow.com/questions/52578966/wpf-binding-datagrid-with-sql-server-database-table/52579280
                }
            }
        }  
        private void GoBackBtn_Click(object sender, RoutedEventArgs e)
        {
            LibraryWindows.AdminPanel adminPanel = new AdminPanel();
            adminPanel.Show();
            this.Close();
        }
        private void LogoutBtn_Click(object sender, RoutedEventArgs e)
        {
            Login_SignupWindows.LoginWindow loginWindow = new Login_SignupWindows.LoginWindow();
            loginWindow.Show();
            this.Close();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            using (SqlConnection con = new SqlConnection(Connection.LibraryConnection.stringConnection))
            {
                con.Open();
                using (SqlDataAdapter a = new SqlDataAdapter(
                    "SELECT * FROM StudentsTbl WHERE Role='"+ "Pending Request" +"'", con))
                {
                    DataTable t = new DataTable();
                    a.Fill(t);
                    TeachersReqDatagrid.ItemsSource = t.DefaultView;
                    // https://stackoverflow.com/questions/52578966/wpf-binding-datagrid-with-sql-server-database-table/52579280
                }
            }     
        }
    }
}
