﻿  using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LibraryManagmentSystem.LibraryWindows
{
    /// <summary>
    /// Interaction logic for MyBooks.xaml
    /// </summary>
    public partial class MyBooks : Window
    {
        public MyBooks()
        {
            InitializeComponent();
        }

        private void ReturnBookBtn_Click(object sender, RoutedEventArgs e)
        {
            if (BookIDTxt.Text == "")
            {
                MessageBox.Show("Please Select the book");
            }

            else
            {
                Connection.ServerWithoutMsgBox.executeSQL("UPDATE StudentsTbl SET AddedBook = AddedBook - 1 WHERE Username ='" + Login_SignupWindows.LoginWindow.recBy + "'");
                if (Connection.ServerWithoutMsgBox.blCheck == false)
                    return;
                Connection.ServerWithoutMsgBox.executeSQL("INSERT INTO ReturnedBooksTbl (Book_ID, Book_Name, ReturnedBy, Returned_Time) SELECT Book_ID, Book_Name, AddedBy, '" + DateTime.Now.ToString("MM/dd/yyyy") + "' FROM AddedBooksTbl WHERE Book_ID='" + BookIDTxt.Text + "'");
                if (Connection.ServerWithoutMsgBox.blCheck == false)
                    return;
                Connection.ServerWithoutMsgBox.executeSQL("DELETE AddedBooksTbl WHERE Book_ID='" + BookIDTxt.Text + "' ");
                if (Connection.LibraryConnection.blCheck == false)
                {
                    return;
                }
                using (SqlConnection con = new SqlConnection(Connection.LibraryConnection.stringConnection))
                {
                    con.Open();
                    using (SqlDataAdapter a = new SqlDataAdapter(
                        "SELECT * FROM AddedBooksTbl WHERE AddedBy='" + Login_SignupWindows.LoginWindow.recBy + "'", con))
                    {
                        DataTable t = new DataTable();
                        a.Fill(t);
                        MyBooksDatagrid.ItemsSource = t.DefaultView;
                        // https://stackoverflow.com/questions/52578966/wpf-binding-datagrid-with-sql-server-database-table/52579280
                    }
                }
            }
        }
        private void GoBackBtn_Click(object sender, RoutedEventArgs e)
        {
            StudentPanel studentPanel = new StudentPanel();
            studentPanel.Show();
            this.Close();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            lblloggeninUser.Content = Login_SignupWindows.LoginWindow.recBy;
            usernameTxt.Text = lblloggeninUser.Content.ToString();
            using (SqlConnection con = new SqlConnection(Connection.LibraryConnection.stringConnection))
            {
                con.Open();
                using (SqlDataAdapter a = new SqlDataAdapter(
                    "SELECT * FROM AddedBooksTbl WHERE AddedBy='" + Login_SignupWindows.LoginWindow.recBy + "'", con))
                {
                    DataTable t = new DataTable();
                    a.Fill(t);
                    MyBooksDatagrid.ItemsSource = t.DefaultView;
                    // https://stackoverflow.com/questions/52578966/wpf-binding-datagrid-with-sql-server-database-table/52579280
                }
            }
        }
    }
}
