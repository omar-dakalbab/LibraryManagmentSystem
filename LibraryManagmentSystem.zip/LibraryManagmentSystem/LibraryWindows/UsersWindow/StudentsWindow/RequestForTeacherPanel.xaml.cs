﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LibraryManagmentSystem.LibraryWindows
{
    /// <summary>
    /// Interaction logic for RequestForTeacherPanel.xaml
    /// </summary>
    public partial class RequestForTeacherPanel : Window
    {
        public RequestForTeacherPanel()
        {
            InitializeComponent();
            lblMessageRequest.Visibility = Visibility.Hidden;
        }

        private void LogoutBtn_Click(object sender, RoutedEventArgs e)
        {
            Login_SignupWindows.LoginWindow loginWindow = new Login_SignupWindows.LoginWindow();
            loginWindow.Show();
            this.Close();
        }

        private void SendRequestBtn_Click(object sender, RoutedEventArgs e)
        {
            DataTable dt = Connection.ServerWithoutMsgBox.executeSQL("SELECT Email From StudentsTbl where Email='"+EmailTxt.Text+"' AND Username='"+ Login_SignupWindows.LoginWindow.recBy +"'");
            if (dt.Rows.Count > 0)
            {
                string pending = "Pending Request";
                Connection.LibraryConnection.executeSQL("UPDATE StudentsTbl SET Role='" + pending + "' WHERE Username='" + UsernameTxt.Text + "' OR User_ID ='" + UsernameTxt.Text + "'", "Request has been sent");
                if (Connection.LibraryConnection.blCheck == false)
                {
                    return;
                }
                else
                {
                    lblMessageRequest.Visibility = Visibility.Visible;
                }
            }
            else
            {
                MessageBox.Show("Your email is wrong, please re-enter your registered email");
            }
            
        }

        private void GoBackBtn_Click(object sender, RoutedEventArgs e)
        {
            LibraryWindows.StudentPanel studentPanel = new StudentPanel();
            studentPanel.Show();
            this.Close();
        }
    }
}
