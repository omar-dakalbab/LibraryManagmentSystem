﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LibraryManagmentSystem.LibraryWindows
{
    /// <summary>
    /// Interaction logic for TeacherPanel.xaml
    /// </summary>
    public partial class TeacherPanel : Window
    {
        public TeacherPanel()
        {
            InitializeComponent();
        }
        public static string Role;
        public static string recByRoleTeacher
        {
            get { return Role; }
            set { Role = value; }
        }
        private void AddBookBtn_Click(object sender, RoutedEventArgs e)
        {
            var endDate = DateTime.Now.Date.AddDays(180).ToString("MM/dd/yyyy"); //Add 7 days
            DataTable dataTable1 = Connection.ServerWithoutMsgBox.executeSQL("SELECT Book_ID FROM AddedBooksTbl Where Book_ID='" + BookIDTxt.Text + "' AND AddedBy='" + Login_SignupWindows.LoginWindow.recBy + "'");
            if (dataTable1.Rows.Count > 0)
            {
                System.Windows.MessageBox.Show("The book already exists");
                return;
            }
            Connection.ConnectionForBooksMsg.executeSQL("UPDATE TeachersTbl SET AddedBook = AddedBook + 1 WHERE Username ='" + Login_SignupWindows.LoginWindow.recBy + "' OR Email='" + Login_SignupWindows.LoginWindow.recBy + "'", "You have reached the maximum limit of books");
            if (Connection.ConnectionForBooksMsg.blCheck == false)
                return;
            Connection.ServerWithoutMsgBox.executeSQL("UPDATE BookTbl SET Book_Quantity = Book_Quantity - 1 WHERE Book_ID ='" + BookIDTxt.Text + "' ");
            if (Connection.ServerWithoutMsgBox.blCheck == false)
                return;
            Connection.ServerWithoutMsgBox.executeSQL("INSERT INTO AddedBooksTbl (Book_Name, Book_ID, AddedTime,AddedBy, endDate, DateNow)SELECT Book_Name, Book_ID," +
               " '" + DateTime.Now.ToString("MM/dd/yyyy") + "', '" + Login_SignupWindows.LoginWindow.recBy + "'," +
               "'" + endDate + "','" + DateTime.Now.ToString("MM/dd/yyyy") + "' FROM BookTbl WHERE Book_ID = '" + BookIDTxt.Text + "'");
            if (Connection.ServerWithoutMsgBox.blCheck == false)
                return;
            using (SqlConnection con = new SqlConnection(Connection.LibraryConnection.stringConnection))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand("select AddedBook from TeachersTbl where Username = '" + Login_SignupWindows.LoginWindow.recBy + "'  OR Email='" + Login_SignupWindows.LoginWindow.recBy + "'", con))
                {
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {

                        lblBookAdded.Content = reader["AddedBook"].ToString();

                    }
                    reader.Close();
                }
                con.Close();
            }
            using (SqlConnection con = new SqlConnection(Connection.LibraryConnection.stringConnection))
            {   
                con.Open();
                using (SqlDataAdapter a = new SqlDataAdapter(
                    "SELECT Book_ID,Book_Name,Book_Author_Name,Book_PageNumber,Book_PublishedYear,Book_Quantity,Book_Category FROM BookTbl WHERE Book_Quantity <> 0", con))
                {
                    DataTable t = new DataTable();
                    a.Fill(t);
                    BooksDatagrid.ItemsSource = t.DefaultView;



                    // https://stackoverflow.com/questions/52578966/wpf-binding-datagrid-with-sql-server-database-table/52579280
                }
            }
        }
        private void MyBooksBtn_Click(object sender, RoutedEventArgs e)
        {
            LibraryWindows.MyBooksTeachersWindow myBooks = new MyBooksTeachersWindow();
            myBooks.Show();
            this.Close();
        }
        private void LogoutBtn_Click(object sender, RoutedEventArgs e)
        {
            Login_SignupWindows.LoginWindow loginWindow = new Login_SignupWindows.LoginWindow();
            loginWindow.Show();
            this.Close();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            using (SqlConnection con = new SqlConnection(Connection.LibraryConnection.stringConnection))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand("select First_Name from TeachersTbl where Username = '" + Login_SignupWindows.LoginWindow.recBy + "' OR Email='" + Login_SignupWindows.LoginWindow.recBy + "'", con))
                {
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {

                        lblUserLoggedInName.Content = "Hey! " + reader["First_Name"].ToString();

                    }
                    reader.Close();
                }
                con.Close();
            }
            using (SqlConnection con = new SqlConnection(Connection.LibraryConnection.stringConnection))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand("select User_ID from TeachersTbl where Username = '" + Login_SignupWindows.LoginWindow.recBy + "' OR Email='" + Login_SignupWindows.LoginWindow.recBy + "'", con))
                {
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {

                        lblTeacherID.Content = reader["User_ID"].ToString();

                    }
                    reader.Close();
                }
                con.Close();
            }
            using (SqlConnection con = new SqlConnection(Connection.LibraryConnection.stringConnection))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand("select AddedBook from TeachersTbl where Username = '" + Login_SignupWindows.LoginWindow.recBy + "' OR Email='" + Login_SignupWindows.LoginWindow.recBy + "'", con))
                {
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {

                        lblBookAdded.Content = reader["AddedBook"].ToString();

                    }
                    reader.Close();
                }
                con.Close();
            }
            using (SqlConnection con = new SqlConnection(Connection.LibraryConnection.stringConnection))
            {
                con.Open();
                using (SqlDataAdapter a = new SqlDataAdapter(
                    "SELECT Book_ID,Book_Name,Book_Author_Name,Book_PageNumber,Book_PublishedYear,Book_Quantity,Book_Category FROM BookTbl WHERE Book_Quantity <> 0", con))
                {
                    DataTable t = new DataTable();
                    a.Fill(t);
                    BooksDatagrid.ItemsSource = t.DefaultView;



                    // https://stackoverflow.com/questions/52578966/wpf-binding-datagrid-with-sql-server-database-table/52579280
                }
            }
            BookTime();
        }
        public void BookTime()
        {
            Connection.ServerWithoutMsgBox.executeSQL("UPDATE AddedBooksTbl Set DateNow='" + DateTime.Now.ToString("MM/dd/yyyy") + "'");
            DataTable datatable = Connection.ServerWithoutMsgBox.executeSQL("SELECT * FROM AddedBooksTbl WHERE DateNow > endDate AND AddedBy='" + Login_SignupWindows.LoginWindow.recBy + "'");
            if (datatable.Rows.Count <= 0)
            {

                Connection.ServerWithoutMsgBox.blCheck = false;
                return;
            }
            else
            {
                //Connection.ServerWithoutMsgBox.executeSQL("DELETE FROM AddedBooksTbl WHERE DateNow > endDate AND AddedBy='" + Login_SignupWindows.LoginWindow.recBy + "'");
                //System.Windows.MessageBox.Show("Datetime MessageBox");
                System.Windows.MessageBox.Show("Please return the books that are past the delivery time");
                MyBooksTeachersWindow mybookspan = new MyBooksTeachersWindow();
                mybookspan.Show();
                this.Hide();
            }
            Connection.ServerWithoutMsgBox.executeSQL("UPDATE TeachersTbl SET AddedBook = AddedBook - 1 WHERE Username='" + Login_SignupWindows.LoginWindow.recBy + "'  OR Email='" + Login_SignupWindows.LoginWindow.recBy + "'");
            if (Connection.ServerWithoutMsgBox.blCheck == false)
            {
                return;
            }
        }

        private void BooksSearchBarTxt_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (BooksComboBox.SelectedIndex == 0)
            {
                BindingSource bs = new BindingSource();
                bs.DataSource = BooksDatagrid.ItemsSource;
                bs.Filter = "Book_Name LIKE '%" + BooksSearchBarTxt.Text + "%'";
                BooksDatagrid.ItemsSource = bs;
            }
            if (BooksComboBox.SelectedIndex == 1)
            {
                BindingSource bs = new BindingSource();
                bs.DataSource = BooksDatagrid.ItemsSource;
                bs.Filter = "Convert(Book_PageNumber, 'System.String') LIKE '%" + BooksSearchBarTxt.Text + "%'";
                BooksDatagrid.ItemsSource = bs;
            }
            if (BooksComboBox.SelectedIndex == 2)
            {
                BindingSource bs = new BindingSource();
                bs.DataSource = BooksDatagrid.ItemsSource;
                bs.Filter = "Book_Author_Name LIKE '%" + BooksSearchBarTxt.Text + "%'";
                BooksDatagrid.ItemsSource = bs;
            }
            if (BooksComboBox.SelectedIndex == 3)
            {
                BindingSource bs = new BindingSource();
                bs.DataSource = BooksDatagrid.ItemsSource;
                bs.Filter = "Book_Category LIKE '%" + BooksSearchBarTxt.Text + "%'";
                BooksDatagrid.ItemsSource = bs;
            }
            if (BooksComboBox.SelectedIndex == 4)
            {
                BindingSource bs = new BindingSource();
                bs.DataSource = BooksDatagrid.ItemsSource;
                bs.Filter = "Convert(Book_PublishedYear, 'System.String') LIKE '%" + BooksSearchBarTxt.Text + "%'";
                BooksDatagrid.ItemsSource = bs;
            }
            if (BooksComboBox.SelectedIndex == 5)
            {
                BindingSource bs = new BindingSource();
                bs.DataSource = BooksDatagrid.ItemsSource;
                bs.Filter = "Convert(Book_Quantity, 'System.String') LIKE '%" + BooksSearchBarTxt.Text + "%'";
                BooksDatagrid.ItemsSource = bs;
            }
        }
    }
}

