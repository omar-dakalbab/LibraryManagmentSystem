﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace LibraryManagmentSystem.Emails
{
    
    public static class EmailSentMessage
    { 
        public static string to;
        public static void email(string txtEmail, string MessageBody, string EmailSubject, string messageboxstr)
        {
            string from, pass, messageBody;
            MailMessage message = new MailMessage();
            to = (txtEmail).ToString();
            from = "libraryemail011@gmail.com";
            pass = "789123564L";
            messageBody = MessageBody;
            message.From = new MailAddress(from);
            message.Body = messageBody;
            message.Subject = EmailSubject;
            message.To.Add(to);
            SmtpClient smtp = new SmtpClient("smtp.gmail.com");
            smtp.EnableSsl = true;
            smtp.Port = 587;
            smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtp.Credentials = new NetworkCredential(from, pass);
            try
            {
                smtp.Send(message);
                MessageBox.Show(messageboxstr);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
