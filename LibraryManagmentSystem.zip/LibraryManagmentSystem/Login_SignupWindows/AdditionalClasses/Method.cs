﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace LibraryManagmentSystem.Login_SignupWindows.AdditionalClasses
{
    public static class Method
    {
        public static bool blcheck = false;
        private static int minusernamelength = 3;
        private static int minpasswordlength = 8;
        private static string allowedlettersforusername = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ_";
        private static List<char> allowedcharacters = new List<char>();
        static Method()
        {
            foreach (var CultureVr in allowedlettersforusername.ToCharArray())
            {
                allowedcharacters.Add(CultureVr);
            }
            foreach (var CultureVr in allowedlettersforusername.ToLower(new System.Globalization.CultureInfo("en-US")))
            {
                allowedcharacters.Add(CultureVr);
            }
            foreach (var CultureVr in allowedlettersforusername.ToUpper(new System.Globalization.CultureInfo("en-US")))
            {
                allowedcharacters.Add(CultureVr);
            }
            allowedcharacters = allowedcharacters.Distinct().ToList();
        }
        public static void UserVaildation(string username, string email, string dateofbirth, string password, string confirmPassword, string firstname, string lastname)
        {

            string userRole = "Student";

            if (string.IsNullOrEmpty(username))
            {
                MessageBox.Show("Please enter your username");
                return;
            }
            if (username.Length < minusernamelength)
            {
                MessageBox.Show("Your username must be minimum 3");
            }
            if (string.IsNullOrEmpty(email))
            {
                MessageBox.Show("Please enter your Email");
                return;
            }
            if (string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter your password");
                return;
            }
            if (string.IsNullOrEmpty(confirmPassword))
            {
                MessageBox.Show("Please confirm your password");
                return;
            }

            if (password != confirmPassword)
            {
                MessageBox.Show("Please check your passwords");
                return;
            }
            if (password.Length < minpasswordlength)
            {
                MessageBox.Show("Your password must be minimum 8 ");
                return;
            }
            bool blContainsDigit = false, blContainsLetter = false, blContainsUpperCase = false, blContainsLowerCase = false;
            foreach (char vrPerChar1 in password.ToCharArray())
            {
                if (char.IsDigit(vrPerChar1))
                    blContainsDigit = true;
                if (char.IsLetter(vrPerChar1))
                    blContainsLetter = true;
                if (char.IsUpper(vrPerChar1))
                    blContainsUpperCase = true;
                if (char.IsLower(vrPerChar1))
                    blContainsLowerCase = true;
            }
            if (!blContainsDigit)
            {
                MessageBox.Show($"Your password has to contain a numeric character");
                return;
            }
            if (!blContainsLetter)
            {
                MessageBox.Show($"Your password has to contain a letter");
                return;
            }
            if (!blContainsUpperCase)
            {
                MessageBox.Show($"Your password has to contain an upper case character");
                return;
            }

            if (!blContainsLowerCase)
            {
                MessageBox.Show($"Your password has to contain a lower case character");
                return;
            }
            if (!Static.Validate(email))
            {
                MessageBox.Show("Please check your email");
                return;
            }
            else
            {
                DataTable dataTable = Connection.ServerWithoutMsgBox.executeSQL("SELECT Username FROM StudentsTbl Where Username='" + username + "'");
                DataTable dataTable1 = Connection.ServerWithoutMsgBox.executeSQL("SELECT Username FROM TeachersTbl Where Username='" + username + "'");
                if (dataTable.Rows.Count > 0 || dataTable1.Rows.Count > 0)
                {
                    MessageBox.Show("The username already exists");
                    return;
                }
                else
                {
                    DataTable dbUserID = Connection.ServerWithoutMsgBox.executeSQL("SELECT User_ID FROM StudentsTbl where User_ID='" + AdditionalClasses.Static.UserIDRandomizer() + "'");

                    int addedBook = 0;
                    int maxBook = 5;
                    Connection.LibraryConnection.executeSQL("INSERT INTO StudentsTbl (Username, User_ID, Password,Email, First_Name, Last_Name, DateOfBirth, Role, AddedBook, MaxBook)" +
                        " VALUES ('" + username.ToLower() + "','" + AdditionalClasses.Static.UserIDRandomizer() + "','"+AdditionalClasses.Static.ConvertToHash(password) + "','" + email + "','" + firstname.ToUpper() + "','" + lastname.ToUpper() + "','" + dateofbirth + "','" + userRole.ToUpper() + "', '" + addedBook + "','" + maxBook + "')",
                        "You have successfully created your account, You can go back and login");
                    blcheck = true;
                    
                    



                }

            }




        }
    }
}
