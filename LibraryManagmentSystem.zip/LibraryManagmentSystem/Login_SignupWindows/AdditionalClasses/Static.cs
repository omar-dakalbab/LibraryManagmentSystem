﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;

namespace LibraryManagmentSystem.Login_SignupWindows.AdditionalClasses
{
    public static class Static
    {
        public static bool Validate(string emailAddress)
        {
            var regex = @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z";
            bool isValid = Regex.IsMatch(emailAddress, regex, RegexOptions.IgnoreCase);
            return isValid;
        }
        public static string ConvertToHash(this string text)
        {
            byte[] bytes = Encoding.Unicode.GetBytes(text);
            SHA256Managed hashstring = new SHA256Managed();
            byte[] hash = hashstring.ComputeHash(bytes);
            string hashString = string.Empty;
            foreach (byte x in hash)
            {
                hashString += String.Format("{0:x2}", x);
            }
            return hashString;
        }
        public static int UserIDRandomizer()
        {
            Random random = new Random();
            int UserId = random.Next(2000000, 3000000);
            return UserId;
        }
        public static int BookIDRandomizer()
        {
            Random random = new Random();
            int BookId = random.Next(20000, 30000);
            return BookId;
        }
        public static string GetRandomAlphanumericString(int length)
        {
            
            const string alphanumericCharacters =
                "ABCDEFGHIJKLMNOPQRSTUVWXYZ" +
                "abcdefghijklmnopqrstuvwxyz" +
                "0123456789";
            return GetRandomString(length, alphanumericCharacters);
        }

        public static string GetRandomString(int length, IEnumerable<char> characterSet)
        {
            if (length < 0)
                throw new ArgumentException("length must not be negative", "length");
            if (length > int.MaxValue / 8) // 250 million chars ought to be enough for anybody
                throw new ArgumentException("length is too big", "length");
            if (characterSet == null)
                throw new ArgumentNullException("characterSet");
            var characterArray = characterSet.Distinct().ToArray();
            if (characterArray.Length == 0)
                throw new ArgumentException("characterSet must not be empty", "characterSet");
            var bytes = new byte[length * 8];
            new RNGCryptoServiceProvider().GetBytes(bytes);
            var result = new char[length];
            for (int i = 0; i < length; i++)
            {
                ulong value = BitConverter.ToUInt64(bytes, i * 8);
                result[i] = characterArray[value % (uint)characterArray.Length];
            }
            return new string(result);
        }
        public static void GetRandomUsername()
        {
            int numbers = 1000;
            int AddedBooks = 0;
            int MaxBooks = 5;
            string userRole = "Student";
            

            for (int i = 0; i < numbers; i++)
            {
                string Username = FakeData.NameData.GetMaleFirstName();
                string Email = FakeData.NetworkData.GetEmail();
                string Firstname = FakeData.NameData.GetFirstName();
                string Lastname = FakeData.NameData.GetSurname().ToUpper();
                string DateOfBirth = FakeData.DateTimeData.GetDatetime().ToString("MM/dd/yyyy");
                int userid = UserIDRandomizer();
                DataTable dataTables = Connection.ServerWithoutMsgBox.executeSQL("SELECT Username FROM StudentsTbl Where Username='" + Username + "'");
                DataTable dataTableEmails = Connection.ServerWithoutMsgBox.executeSQL("SELECT Email FROM StudentsTbl Where Username='" + Email + "'");
                DataTable dataTableUserids = Connection.ServerWithoutMsgBox.executeSQL("SELECT User_ID FROM StudentsTbl Where User_ID='" + userid + "'");
                DataTable dataTable = Connection.ServerWithoutMsgBox.executeSQL("SELECT Username FROM TeachersTbl Where Username='" + Username + "'");
                DataTable dataTableEmail = Connection.ServerWithoutMsgBox.executeSQL("SELECT Email FROM TeachersTbl Where Username='" + Email + "'");
                DataTable dataTableUserid = Connection.ServerWithoutMsgBox.executeSQL("SELECT User_ID FROM TeachersTbl Where User_ID='" + userid + "'");
                if (dataTable.Rows.Count > 0 || dataTableEmail.Rows.Count > 0 || dataTableUserid.Rows.Count > 0 || dataTables.Rows.Count > 0 || dataTableEmails.Rows.Count > 0 || dataTableUserids.Rows.Count > 0)
                {
                    MessageBox.Show("ERROR");
                    return;
                }
                Connection.ServerWithoutMsgBox.executeSQL("INSERT INTO StudentsTbl (Username, User_ID, Password, Email, First_Name, Last_Name, DateOfBirth, Role, AddedBook, MaxBook)" +
                " VALUES ('" + Username + "','" + userid + "','" + ConvertToHash(GetRandomAlphanumericString(10)) + "','" + Email + "','" + Firstname + "','" + Lastname + "','" + DateOfBirth + "','" + userRole + "', '" + AddedBooks + "','" + MaxBooks + "')");
            }
            MessageBox.Show("Your" + numbers + "users has been added");


        }
       
    

    }
}
