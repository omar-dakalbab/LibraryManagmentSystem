﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LibraryManagmentSystem.Login_SignupWindows
{
    /// <summary>
    /// Interaction logic for SignupWindow.xaml
    /// </summary>
    public partial class SignupWindow : Window
    {
        public SignupWindow()
        {
            InitializeComponent();
        }
        private void LoginLbl_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            Login_SignupWindows.LoginWindow loginWindow = new LoginWindow();
            loginWindow.Show();
            this.Close();
        }
        private void CreateAccountBtn_Click(object sender, RoutedEventArgs e)
        {
            Login_SignupWindows.AdditionalClasses.Method.UserVaildation(Signup_UsernameTxt.Text, Signup_EmailTxt.Text, Signup_DateofBirthTxt.Text, 
                Signup_PasswordTxt.Password, Signup_ConfirmTxt.Password, Signup_FirstNameTxt.Text, Signup_LastNameTxt.Text);
            if(AdditionalClasses.Method.blcheck == true)
            {
                LoginWindow login = new LoginWindow();
                login.Show();
                this.Hide();
            }
           
        }
        private void ExitLabel_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            this.Close();
        }
    }
}
