﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LibraryManagmentSystem.Login_SignupWindows.ForgotPassword
{
    /// <summary>
    /// Interaction logic for SendCodeWindow.xaml
    /// </summary>
    public partial class SendCodeWindow : Window
    {
        string OTPCode;

        public SendCodeWindow()
        {
            InitializeComponent();
        }
        public static string email;
        public static string recByEmail
        {
            get { return email; }
            set { email = value; }
        }
        private void btnSendOtp_Click(object sender, RoutedEventArgs e)
        {
            recByEmail = txtEmail.Text;
            if (RoleCombo.SelectedIndex == 0)
            {
                DataTable dt = Connection.ServerWithoutMsgBox.executeSQL("SELECT * FROM StudentsTbl WHERE Email='" + txtEmail.Text + "'");
                if (dt.Rows.Count > 0)
                {
                    Random rand = new Random();
                    OTPCode = (rand.Next(999999)).ToString();
                    Emails.EmailSentMessage.email(txtEmail.Text ,"Hi Student,\nWe have got a request to reset your password\nYour Reset Code is: " + OTPCode,
                        "Reset Your Password",
                        "Code has been sent");
                }
                else
                {
                    MessageBox.Show("Please enter a vaild email address");
                }
            }
            else if(RoleCombo.SelectedIndex == 1)
            {
                DataTable dt = Connection.ServerWithoutMsgBox.executeSQL("SELECT * FROM TeachersTbl WHERE Email='" + txtEmail.Text + "'");
                if (dt.Rows.Count > 0)
                {
                    
                    Random rand = new Random();
                    OTPCode = (rand.Next(999999)).ToString();
                    Emails.EmailSentMessage.email(txtEmail.Text,"Hi Teacher,\nWe got a request to reset your password\nYour Reset Code is: " + OTPCode,
                        "Reset Your Password",
                        "Code has been sent");                  
                }
                else
                {
                    MessageBox.Show("Please enter a vaild email address");
                }
            }
            else
            {
                MessageBox.Show("Please select a role before sending the code");
                return;
            }
        }
        private void btnVerify_Click(object sender, RoutedEventArgs e)
        {
            if (OTPCode == (txtVerifyCode.Text).ToString())
            {
                Emails.EmailSentMessage.to = txtEmail.Text;
                ForgotPasswordWindow FP = new ForgotPasswordWindow();
                this.Hide();
                FP.Show();
            }
            else
            {
                MessageBox.Show("Check your code");
            }
        }

        private void GoBackBtn_Click(object sender, RoutedEventArgs e)
        {
            LoginWindow login = new LoginWindow();
            login.Show();
            this.Close();
        }
    }
}
