﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input; 
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LibraryManagmentSystem.Login_SignupWindows
{
    /// <summary>
    /// Interaction logic for ForgotPasswordWindow.xaml
    /// </summary>
    public partial class ForgotPasswordWindow : Window
    {
        string username = Emails.EmailSentMessage.to;
        public ForgotPasswordWindow()
        {
            InitializeComponent();
        }

        private void ChangePass_Click(object sender, RoutedEventArgs e)
        {
           DataTable dtStudent = Connection.ServerWithoutMsgBox.executeSQL("SELECT * FROM StudentsTbl WHERE Email='"+ username +"'");
            if (dtStudent.Rows.Count > 0)
            {
                if (Passwordtxt.Password == ConfirmPasstxt.Password)
                {
                    string yourSQL = "UPDATE StudentsTbl set Password = '" + AdditionalClasses.Static.ConvertToHash(Passwordtxt.Password) + "' where Email= '" + username + "'";
                    DataTable UpdatePassword = Connection.ServerWithoutMsgBox.executeSQL(yourSQL);
                    MessageBox.Show("Password Reset Successfully...");
                    this.Close();
                    Login_SignupWindows.LoginWindow log = new Login_SignupWindows.LoginWindow();
                    log.Show();
                }
                else
                {
                    MessageBox.Show("the new Password do not match");
                }
            }
            else
            {
                MessageBox.Show("Error Occured, please try again later");
            }
            DataTable dtTeacher = Connection.ServerWithoutMsgBox.executeSQL("SELECT * FROM TeachersTbl WHERE Email='" + username + "'");
            if (dtTeacher.Rows.Count > 0)
            {
                if (Passwordtxt.Password == ConfirmPasstxt.Password)
                {
                    string yourSQL = "UPDATE TeachersTbl set Password = '" + ConfirmPasstxt.Password + "' where Email= '" + username + "'";
                    DataTable UpdatePassword = Connection.ServerWithoutMsgBox.executeSQL(yourSQL);
                    MessageBox.Show("Password Reset Successfully...");
                    this.Close();
                    Login_SignupWindows.LoginWindow log = new Login_SignupWindows.LoginWindow();
                    log.Show();
                }
                else
                {
                    MessageBox.Show("the new Password do not match");
                }
            }
            
        }
    }
}
