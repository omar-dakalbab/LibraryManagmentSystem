﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LibraryManagmentSystem.Login_SignupWindows
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }
        public static string username;
        public static string recBy
        {
            get { return username; }
            set { username = value; }
        } // get set to take username and return it.
        
        
        private void CreateAccountBtn_Click(object sender, RoutedEventArgs e) //Go to SignupWindow Button
        {
            Login_SignupWindows.SignupWindow SignupWindow = new SignupWindow();
            SignupWindow.Show();
            this.Close();
        }

        private void LoginBtn_Click(object sender, RoutedEventArgs e) // Login Button
        {
            if (Login_UsernameTxt.Text == "admin" && Login_PasswordTxt.Password == "admin") 
            {
                LibraryWindows.AdminPanel admnPnl = new LibraryWindows.AdminPanel();
                recBy = Login_UsernameTxt.Text;
                admnPnl.Show();
                this.Close();
            }

            string userloggedin = Login_UsernameTxt.Text.ToString();
            string passloggedin = AdditionalClasses.Static.ConvertToHash(Login_PasswordTxt.Password.ToString());
            if (StudentRadioBtn.IsChecked == true)
            {
                
               
                if (!string.IsNullOrEmpty(Login_UsernameTxt.Text) && !string.IsNullOrEmpty(Login_PasswordTxt.Password))
                {
                    string mySQL = string.Empty;
                    mySQL += "SELECT * FROM StudentsTbl ";
                    mySQL += "WHERE Username = '" + userloggedin + "' AND Password = '" + passloggedin + "' OR Email='"+ userloggedin +"' AND Password='"+passloggedin+"'";
                    DataTable userData = LibraryManagmentSystem.Connection.ServerWithoutMsgBox.executeSQL(mySQL);

                    if (userData.Rows.Count > 0)
                    {
                        recBy = Login_UsernameTxt.Text;
                        Login_UsernameTxt.Clear();
                        Login_PasswordTxt.Clear();
                        LibraryWindows.StudentPanel studentPanel = new LibraryWindows.StudentPanel();
                        studentPanel.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("The username or password is incorrect. Try again");
                    }
                }
                else
                {
                    MessageBox.Show("Please enter your username and Pssword");
                }
            }



            if (TeacherRadioBtn.IsChecked == true)
            {
                if (!string.IsNullOrEmpty(Login_UsernameTxt.Text) && !string.IsNullOrEmpty(Login_PasswordTxt.Password))
                {
                    string mySQL = string.Empty;
                    mySQL += "SELECT * FROM TeachersTbl ";
                    mySQL += "WHERE Username = '" + userloggedin + "' AND Password = '" + passloggedin + "' OR Email='" + userloggedin + "' AND Password='" + passloggedin + "'";
                    DataTable userData = LibraryManagmentSystem.Connection.ServerWithoutMsgBox.executeSQL(mySQL);

                    if (userData.Rows.Count > 0)
                    {

                        recBy = Login_UsernameTxt.Text;
                        Login_UsernameTxt.Clear();
                        Login_PasswordTxt.Clear();
                        LibraryWindows.TeacherPanel teacherPanel = new LibraryWindows.TeacherPanel();
                        teacherPanel.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("The username or password is incorrect. Try again");
                    }
                }
                else
                {
                    MessageBox.Show("Please enter your username and Pssword");
                }
            }
        }
        
        private void ExitLabel_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            this.Close();
        }

        

        private void ForgorPassword_Click(object sender, RoutedEventArgs e)
        {
            ForgotPassword.SendCodeWindow forgor = new ForgotPassword.SendCodeWindow();
            forgor.Show();
            this.Hide();
        }
       
        
       
        

        
    }
}